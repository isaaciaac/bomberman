"""Entropy-driven Memory Reconstruction demo package."""

